/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agenda; // Define el paquete al que pertenece la clase

import java.sql.Connection; // Importa la clase Connection para manejar la conexión a la base de datos
import java.sql.DriverManager; // Importa DriverManager para establecer la conexión
import java.sql.SQLException; // Importa SQLException para manejar errores de SQL

public class DatabaseConnection { // Clase responsable de gestionar la conexión a la base de datos
    // URL de la base de datos, usuario y contraseña
    private static final String URL = "jdbc:mysql://localhost:3306/agendadb"; // URL de conexión a la base de datos
    private static final String USER = "root"; // Usuario de la base de datos
    private static final String PASSWORD = ""; // Contraseña del usuario

    // Método para obtener una conexión a la base de datos
    public static Connection getConnection() {
        try {
            // Intenta establecer la conexión utilizando DriverManager
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) { // Maneja cualquier error de SQL
            e.printStackTrace(); // Imprime el error en la consola
            return null; // Devuelve null si no se pudo establecer la conexión
        }
    }
}

