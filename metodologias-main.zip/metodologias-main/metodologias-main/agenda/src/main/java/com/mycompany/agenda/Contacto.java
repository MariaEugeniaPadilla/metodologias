
package com.mycompany.agenda; // Define el paquete al que pertenece la clase

public class Contacto { 
    private int id; 
    private String nombre;
    private String telefono;
    private String correo;

    public Contacto(int id, String nombre, String telefono, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
    }

    public int getId() {
        return id; // Devuelve el valor del atributo id
    }

    // Método getter para obtener el nombre del contacto
    public String getNombre() {
        return nombre; // Devuelve el valor del atributo nombre
    }

    // Método getter para obtener el teléfono del contacto
    public String getTelefono() {
        return telefono; // Devuelve el valor del atributo telefono
    }

    // Método getter para obtener el email del contacto
    public String getEmail() {
        return correo; // Devuelve el valor del atributo email
    }
}

