
package com.mycompany.agenda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList; 
import java.util.List;

public class ContactoDAO { 

    public void agregarContacto(String nombre, String telefono, String correo) {
        Connection conn = DatabaseConnection.getConnection();
        String sql = "INSERT INTO contactos (nombre, telefono, correo) VALUES (?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setString(2, telefono);
            stmt.setString(3, correo);
            stmt.executeUpdate();
            System.out.println("EL CONTACTO HA SIDO AGREGADO DE MANERA EXITOSA");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Contacto> obtenerContactos() {
        Connection conn = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM contactos";
        List<Contacto> contactos = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                
                Contacto contacto = new Contacto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo")
                );
                contactos.add(contacto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contactos;
    }
    
    
    public void editarContacto(int id, String nombre, String telefono, String correo) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE contactos SET nombre = ?, telefono = ?, correo = ? WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nombre);
            pst.setString(2, telefono);
            pst.setString(3, correo);
            pst.setInt(4, id);
            pst.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void eliminarContacto(int id) {
        Connection conn = DatabaseConnection.getConnection();
        String sql = "DELETE FROM contactos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int filasEliminadas = stmt.executeUpdate();
            
            if (filasEliminadas > 0) {
                System.out.println("CONTACTO ELIMINADO EXITOSAMENTE");
            } else {
                System.out.println("NO SE ENCONTRO EL CONTACTO CON EL ID:" + id);
            }
        } catch (SQLException e) { 
            e.printStackTrace();
        } finally {
            
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

