/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agenda; // Define el paquete al que pertenece la clase

import java.sql.Connection; // Importa la clase Connection para manejar la conexión a la base de datos
import java.sql.DriverManager; // Importa DriverManager para establecer la conexión
import java.sql.SQLException; // Importa SQLException para manejar errores de SQL

public class DatabaseConnection { // Clase responsable de gestionar la conexión a la base de datos
    // URL de la base de datos, usuario y contraseña
    private static final String URL = "jdbc:mysql://localhost:3306/agenda_db"; // URL de conexión a la base de datos
    private static final String USER = "root"; // Usuario de la base de datos
    private static final String PASSWORD = ""; // Contraseña del usuario

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void probarConexion() {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                System.out.println("¡Conexión exitosa a la base de datos!");
            } else {
                System.out.println("Error al conectar a la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Excepción al conectar: " + e.getMessage());
        }
    }
}

