package com.mycompany.agenda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContactoDAO {

    public int agregarContacto(String nombre, String telefono, String correo) {
        String sql = "INSERT INTO contactos (nombre, telefono, correo) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, nombre);
            stmt.setString(2, telefono);
            stmt.setString(3, correo);
            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1); // Retorna el ID generado
                    }
                }
            }
            System.out.println("CONTACTO AGREGADO EXITOSAMENTE");
        } catch (SQLException e) {
            System.err.println("Error al agregar el contacto: " + e.getMessage());
        }
        return -1; // Retorna -1 si no se pudo generar el ID
    }

    public void editarContacto(int id, String nombre, String telefono, String correo) {
        String sql = "UPDATE contactos SET nombre = ?, telefono = ?, correo = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, nombre);
            pst.setString(2, telefono);
            pst.setString(3, correo);
            pst.setInt(4, id);
            int filasAfectadas = pst.executeUpdate();
            
            if (filasAfectadas > 0) {
                System.out.println("CONTACTO EDITADO EXITOSAMENTE");
            } else {
                System.out.println("No se encontró un contacto con ID: " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error al editar el contacto: " + e.getMessage());
        }
    }

    public void eliminarContacto(int id) {
        String sql = "DELETE FROM contactos WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            int filasEliminadas = stmt.executeUpdate();
            
            if (filasEliminadas > 0) {
                System.out.println("CONTACTO ELIMINADO EXITOSAMENTE");
            } else {
                System.out.println("No se encontró el contacto con ID: " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar el contacto: " + e.getMessage());
        }
    }

    public List<Contacto> obtenerContactos() {
        List<Contacto> contactos = new ArrayList<>();
        String sql = "SELECT id, nombre, telefono, correo FROM contactos";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Contacto contacto = new Contacto();
                contacto.setId(rs.getInt("id"));
                contacto.setNombre(rs.getString("nombre"));
                contacto.setTelefono(rs.getString("telefono"));
                contacto.setCorreo(rs.getString("correo"));
                contactos.add(contacto);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los contactos: " + e.getMessage());
        }
        return contactos;
    }
}
